import React, { useEffect, useRef, useState } from 'react';
import { View, Text, TextInput, Pressable, FlatList, Modal, StyleSheet, SafeAreaView,
  KeyboardAvoidingView, Platform, ActivityIndicator, Alert, StatusBar } from 'react-native';
import Markdown from 'react-native-markdown-display';
import { MODELS, recommended, ramGB, isDownloaded, download } from './src/models';
import { loadModel, reply, stop } from './src/engine';
import { loadChats, saveChats, loadCfg, saveCfg } from './src/store';

const BG = '#12151C', PANEL = '#1A1E28', LINE = '#262B38', TXT = '#E6E9F2', DIM = '#8A92A6';
const ACCENTS = ['#8FA2FF', '#7FD6C2', '#E3B27A', '#C99BFF'];
const newChat = () => ({ id: String(Date.now()), title: 'Nuevo chat', messages: [] });

export default function App() {
  const [cfg, setCfg] = useState({ accent: ACCENTS[0] });
  const [chats, setChats] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [model, setModel] = useState(recommended());
  const [phase, setPhase] = useState('boot'); // boot | setup | loading | ready
  const [progress, setProgress] = useState(0);
  const [downloading, setDownloading] = useState(false);
  const [menu, setMenu] = useState(false);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const dl = useRef(null), list = useRef(null);
  const A = cfg.accent;

  useEffect(() => { (async () => {
    setCfg(await loadCfg());
    const c = await loadChats(); const first = c[0] || newChat();
    setChats(c.length ? c : [first]); setActiveId(first.id);
    (await isDownloaded(model)) ? boot(model) : setPhase('setup');
  })(); }, []);

  const boot = async m => {
    setPhase('loading');
    try { await loadModel(m); setPhase('ready'); }
    catch (e) { Alert.alert('No se pudo cargar el modelo', String(e.message || e)); setPhase('setup'); }
  };
  const startDownload = async () => {
    setDownloading(true); setProgress(0);
    dl.current = download(model, setProgress);
    try { await dl.current.run(); setDownloading(false); boot(model); }
    catch (e) { setDownloading(false); Alert.alert('Descarga fallida', 'Revisa tu conexión Wi-Fi e inténtalo de nuevo.'); }
  };

  const chat = chats.find(c => c.id === activeId) || chats[0];
  const update = (id, fn) => setChats(prev => {
    const next = prev.map(c => (c.id === id ? fn(c) : c)); saveChats(next); return next; });

  const send = async () => {
    const text = input.trim(); if (!text || busy) return;
    const id = chat.id, history = [...chat.messages, { role: 'user', content: text }];
    setInput(''); setBusy(true);
    update(id, c => ({ ...c, title: c.messages.length ? c.title : text.slice(0, 32),
      messages: [...history, { role: 'assistant', content: '' }] }));
    let acc = '';
    try {
      await reply(history, t => { acc += t;
        update(id, c => { const m = [...c.messages]; m[m.length - 1] = { role: 'assistant', content: acc }; return { ...c, messages: m }; }); });
    } catch (e) { Alert.alert('Error', String(e.message || e)); }
    setBusy(false);
  };
  const add = () => { const c = newChat(); const n = [c, ...chats]; setChats(n); saveChats(n); setActiveId(c.id); setMenu(false); };
  const remove = id => Alert.alert('Eliminar chat', '¿Eliminar esta conversación?', [
    { text: 'Cancelar' }, { text: 'Eliminar', style: 'destructive', onPress: () => {
      let n = chats.filter(c => c.id !== id); if (!n.length) n = [newChat()];
      setChats(n); saveChats(n); setActiveId(n[0].id); } }]);
  const setAccent = a => { const c = { ...cfg, accent: a }; setCfg(c); saveCfg(c); };

  if (phase !== 'ready') return (
    <SafeAreaView style={[s.root, s.center]}>
      <Text style={[s.logo, { color: A }]}>NEXUS AI</Text>
      {phase === 'setup' ? (<>
        <Text style={s.p}>Tu IA corre dentro del teléfono. Descarga el modelo una vez (con Wi-Fi) y después funciona sin Internet.</Text>
        <Text style={s.dim}>Tu equipo: ~{ramGB().toFixed(1)} GB de RAM</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', marginVertical: 14 }}>
          {MODELS.map(m => (
            <Pressable key={m.id} disabled={downloading} onPress={() => setModel(m)}
              style={[s.chip, { borderColor: model.id === m.id ? A : LINE }]}>
              <Text style={{ color: TXT }}>{m.name}</Text>
              <Text style={s.dim}>{m.sizeMB} MB · {m.minRamGB ? `desde ${m.minRamGB} GB` : 'cualquier equipo'}</Text>
            </Pressable>))}
        </View>
        {model.minRamGB > ramGB() + 0.5 && <Text style={[s.dim, { color: '#E3B27A' }]}>Este modelo puede ir lento o cerrarse en tu equipo.</Text>}
        {downloading
          ? <><Text style={s.p}>Descargando {Math.round(progress * 100)}%</Text>
              <Pressable onPress={() => { dl.current?.cancel(); setDownloading(false); }}><Text style={{ color: A }}>Cancelar</Text></Pressable></>
          : <Pressable style={[s.btn, { backgroundColor: A }]} onPress={startDownload}><Text style={s.btnT}>Descargar {model.name}</Text></Pressable>}
      </>) : <><ActivityIndicator color={A} /><Text style={s.dim}>Cargando el modelo…</Text></>}
    </SafeAreaView>);

  return (
    <SafeAreaView style={s.root}>
      <StatusBar barStyle="light-content" />
      <View style={s.bar}>
        <Pressable onPress={() => setMenu(true)}><Text style={[s.icon, { color: A }]}>☰</Text></Pressable>
        <Text style={s.title} numberOfLines={1}>{chat?.title}</Text>
        <Pressable onPress={add}><Text style={[s.icon, { color: A }]}>＋</Text></Pressable>
      </View>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <FlatList ref={list} data={chat?.messages || []} keyExtractor={(_, i) => String(i)}
          contentContainerStyle={{ padding: 14 }}
          onContentSizeChange={() => list.current?.scrollToEnd({ animated: false })}
          ListEmptyComponent={<Text style={[s.dim, { textAlign: 'center', marginTop: 80 }]}>Pregúntame algo: matemáticas, código, historia, ciencia…</Text>}
          renderItem={({ item }) => item.role === 'user'
            ? <View style={[s.user, { backgroundColor: A }]}><Text style={{ color: BG }}>{item.content}</Text></View>
            : <View style={s.bot}>{item.content
                ? <Markdown style={{ body: { color: TXT, fontSize: 15 }, code_inline: { backgroundColor: PANEL, color: A },
                    fence: { backgroundColor: PANEL, color: TXT }, code_block: { backgroundColor: PANEL, color: TXT } }}>{item.content}</Markdown>
                : <ActivityIndicator color={A} />}</View>} />
        <View style={s.inputRow}>
          <TextInput style={s.input} value={input} onChangeText={setInput} placeholder="Escribe un mensaje" placeholderTextColor={DIM} multiline />
          <Pressable style={[s.send, { backgroundColor: A }]} onPress={busy ? stop : send}>
            <Text style={s.btnT}>{busy ? '■' : '↑'}</Text></Pressable>
        </View>
      </KeyboardAvoidingView>
      <Modal visible={menu} animationType="slide" transparent onRequestClose={() => setMenu(false)}>
        <View style={s.drawer}><SafeAreaView style={{ flex: 1 }}>
          <Pressable style={[s.btn, { backgroundColor: A, margin: 14 }]} onPress={add}><Text style={s.btnT}>Nuevo chat</Text></Pressable>
          <FlatList data={chats} keyExtractor={c => c.id} renderItem={({ item }) => (
            <Pressable style={[s.row, item.id === activeId && { backgroundColor: PANEL }]}
              onPress={() => { setActiveId(item.id); setMenu(false); }} onLongPress={() => remove(item.id)}>
              <Text style={{ color: TXT, flex: 1 }} numberOfLines={1}>{item.title}</Text>
              <Pressable onPress={() => remove(item.id)}><Text style={s.dim}>Eliminar</Text></Pressable>
            </Pressable>)} />
          <View style={{ padding: 14, flexDirection: 'row', alignItems: 'center' }}>
            <Text style={s.dim}>Color</Text>
            {ACCENTS.map(a => <Pressable key={a} onPress={() => setAccent(a)}
              style={{ width: 26, height: 26, borderRadius: 13, backgroundColor: a, marginLeft: 12, borderWidth: a === A ? 2 : 0, borderColor: TXT }} />)}
            <Pressable style={{ marginLeft: 'auto' }} onPress={() => setMenu(false)}><Text style={{ color: A }}>Cerrar</Text></Pressable>
          </View></SafeAreaView></View>
      </Modal>
    </SafeAreaView>);
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: BG }, center: { alignItems: 'center', justifyContent: 'center', padding: 24 },
  logo: { fontSize: 34, fontWeight: '700', letterSpacing: 2, marginBottom: 18 },
  p: { color: TXT, textAlign: 'center', fontSize: 15, marginBottom: 8, lineHeight: 22 },
  dim: { color: DIM, fontSize: 12, textAlign: 'center' },
  chip: { borderWidth: 1.5, borderRadius: 12, padding: 12, margin: 5, minWidth: 140, alignItems: 'center' },
  btn: { borderRadius: 12, paddingVertical: 13, paddingHorizontal: 22, alignItems: 'center' },
  btnT: { color: BG, fontWeight: '700', fontSize: 15 },
  bar: { flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderColor: LINE },
  icon: { fontSize: 24, paddingHorizontal: 6 }, title: { flex: 1, color: TXT, textAlign: 'center', fontSize: 16, fontWeight: '600' },
  user: { alignSelf: 'flex-end', maxWidth: '85%', padding: 11, borderRadius: 16, marginBottom: 10 },
  bot: { alignSelf: 'flex-start', maxWidth: '95%', marginBottom: 10 },
  inputRow: { flexDirection: 'row', padding: 10, alignItems: 'flex-end', borderTopWidth: 1, borderColor: LINE },
  input: { flex: 1, color: TXT, backgroundColor: PANEL, borderRadius: 18, paddingHorizontal: 14, paddingVertical: 10, maxHeight: 120 },
  send: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center', marginLeft: 8 },
  drawer: { width: '82%', height: '100%', backgroundColor: BG, borderRightWidth: 1, borderColor: LINE },
  row: { flexDirection: 'row', padding: 14, alignItems: 'center' },
});
