import * as Device from 'expo-device';
import * as FileSystem from 'expo-file-system/legacy';

// Todos son GGUF cuantizados Q4_K_M de Qwen2.5-Instruct (HuggingFace oficial).
// VERIFICA cada URL en el navegador antes de publicar.
const HF = (repo, file) => `https://huggingface.co/${repo}/resolve/main/${file}`;
export const MODELS = [
  { id: 'qwen25-0.5b', name: 'Nexus Lite (0.5B)', minRamGB: 0, sizeMB: 400,
    file: 'qwen2.5-0.5b-instruct-q4_k_m.gguf',
    url: HF('Qwen/Qwen2.5-0.5B-Instruct-GGUF', 'qwen2.5-0.5b-instruct-q4_k_m.gguf') },
  { id: 'qwen25-1.5b', name: 'Nexus Base (1.5B)', minRamGB: 4, sizeMB: 1100,
    file: 'qwen2.5-1.5b-instruct-q4_k_m.gguf',
    url: HF('Qwen/Qwen2.5-1.5B-Instruct-GGUF', 'qwen2.5-1.5b-instruct-q4_k_m.gguf') },
  { id: 'qwen25-3b', name: 'Nexus Pro (3B)', minRamGB: 6, sizeMB: 2100,
    file: 'qwen2.5-3b-instruct-q4_k_m.gguf',
    url: HF('Qwen/Qwen2.5-3B-Instruct-GGUF', 'qwen2.5-3b-instruct-q4_k_m.gguf') },
];

export const ramGB = () => (Device.totalMemory ? Device.totalMemory / 1024 ** 3 : 4);

// Modelo más grande que cabe con margen (RAM total >= minRamGB aprox.).
export const recommended = () => {
  const r = ramGB() + 0.5; // los equipos "4 GB" reportan ~3.6
  return [...MODELS].reverse().find(m => r >= m.minRamGB) || MODELS[0];
};
export const pathOf = m => FileSystem.documentDirectory + m.file;
export const isDownloaded = async m => (await FileSystem.getInfoAsync(pathOf(m))).exists;

export function download(m, onProgress) {
  const dl = FileSystem.createDownloadResumable(m.url, pathOf(m) + '.part', {},
    p => onProgress(p.totalBytesWritten / p.totalBytesExpectedToWrite));
  return {
    run: async () => {
      await dl.downloadAsync();
      await FileSystem.moveAsync({ from: pathOf(m) + '.part', to: pathOf(m) });
    },
    cancel: () => dl.pauseAsync(),
  };
}
