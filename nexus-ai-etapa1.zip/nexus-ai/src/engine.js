import { initLlama } from 'llama.rn';
import { Platform } from 'react-native';
import { pathOf } from './models';

let ctx = null, loadedId = null;

export async function loadModel(m, onProgress) {
  if (ctx && loadedId === m.id) return;
  await unloadModel();
  ctx = await initLlama({
    model: pathOf(m).replace('file://', ''),
    n_ctx: 2048,
    n_gpu_layers: Platform.OS === 'ios' ? 99 : 0, // GPU Metal en iOS; CPU en Android
  }, onProgress);
  loadedId = m.id;
}
export async function unloadModel() {
  if (ctx) { await ctx.release(); ctx = null; loadedId = null; }
}

const SYSTEM = 'Eres NEXUS AI, un asistente que funciona localmente en el teléfono del usuario. ' +
  'Responde siempre en español, con claridad y en formato Markdown. Explica paso a paso en ' +
  'matemáticas y programación. Si no estás seguro o puedes equivocarte, dilo; si te corrigen y ' +
  'tienen razón, reconoce el error.';

// Memoria contextual: system + últimos 12 mensajes (cabe en n_ctx=2048).
export async function reply(history, onToken) {
  if (!ctx) throw new Error('Modelo no cargado');
  const messages = [{ role: 'system', content: SYSTEM },
    ...history.slice(-12).map(({ role, content }) => ({ role, content }))];
  const r = await ctx.completion(
    { messages, n_predict: 700, temperature: 0.7, top_p: 0.9, stop: ['<|im_end|>'] },
    d => onToken(d.token));
  return r.text;
}
export const stop = () => ctx && ctx.stopCompletion();
