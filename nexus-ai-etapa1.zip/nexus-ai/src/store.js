import AsyncStorage from '@react-native-async-storage/async-storage';
const K = { chats: 'nexus.chats', cfg: 'nexus.cfg' };
export const loadChats = async () => JSON.parse((await AsyncStorage.getItem(K.chats)) || '[]');
export const saveChats = c => AsyncStorage.setItem(K.chats, JSON.stringify(c));
export const loadCfg = async () => ({ accent: '#8FA2FF', ...JSON.parse((await AsyncStorage.getItem(K.cfg)) || '{}') });
export const saveCfg = c => AsyncStorage.setItem(K.cfg, JSON.stringify(c));
