# NEXUS AI — Etapa 1

IA local (llama.cpp vía llama.rn). Requiere *development build*: NO funciona en Expo Go.

## Compilar
```
npx create-expo-app@latest nexus-ai --template blank
cd nexus-ai            # copia aquí App.js, app.json y la carpeta src/
npx expo install llama.rn expo-device expo-file-system @react-native-async-storage/async-storage
npm install react-native-markdown-display
npx expo prebuild
npx expo run:android   # o: npx expo run:ios (requiere Mac + Xcode)
```
Si tu SDK es anterior a 54, cambia `expo-file-system/legacy` por `expo-file-system` en src/models.js.
Para publicar en tiendas: `eas build`.

## Prueba offline
Abre la app con Wi-Fi, descarga el modelo, activa modo avión, reinicia la app y chatea.
